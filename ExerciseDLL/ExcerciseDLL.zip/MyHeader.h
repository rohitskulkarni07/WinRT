
//Following Function Does the addition of two integers 
//Funtion Require 2 arguments i.e 2 numbers to be add
//Funtion returns Addition of two given numbera which is also a int

extern "C" int AdditionOfTwoInt(int, int);

//___________________________________________________________________________________________________________
//___________________________________________________________________________________________________________



//Following Function Does the Subtraction of two integers 
//Funtion Require 2 arguments i.e 2 numbers to be subtract
//Funtion returns Subtraction of two given numbers which is also a integer.

extern "C" int SubtractionOfTwoInt(int, int);

//___________________________________________________________________________________________________________
//___________________________________________________________________________________________________________



//Following Function Does the Multiplication of two integers 
//Funtion Require 2 arguments i.e 2 numbers to be Multiply.
//Funtion returns Multiplication of two given numbera which is also a integer.

extern "C" int MultiplicationOfTwoInt(int, int);


//___________________________________________________________________________________________________________
//___________________________________________________________________________________________________________

//Following Function Does the Division of two Numbers
//Funtion Require 2 arguments i.e 2 numbers to be divide
//Funtion returns Divsion of two given numbers which is a integer

extern "C" int DivisionOfTwoInt(int,int);


//___________________________________________________________________________________________________________
//___________________________________________________________________________________________________________

//Following Function Does the Modulus of two Numbers
//Funtion Require 2 arguments i.e 2 numbers to be mod
//Funtion returns modulus of two given numbers which are integers

extern "C" int ModOfTwoInt(int, int);


//___________________________________________________________________________________________________________
//___________________________________________________________________________________________________________

//Following function Swaps the two integer given to as a parameter to it.
//Funtion requires 2 paramenter i.e. 2 number which we want swap
//Funtion returns nothing but it display the message box to indicate that swapping is done.

extern "C" void SwapTwoIntUsingTemp(int, int);


//___________________________________________________________________________________________________________
//___________________________________________________________________________________________________________


//Following function Swaps the two integer given to as a parameter to it without using extra variable.
//Funtion requires 2 paramenter i.e. 2 number which we want swap
//Funtion returns nothing but it display the message box to indicate that swapping is done.

extern "C" void SwapTwoIntWithoutTemp(int, int);


//___________________________________________________________________________________________________________
//___________________________________________________________________________________________________________

